Ajar Sans is honestly nothing more than the uprights from Google's Open Sans
with about three degrees of right slope. It is thus subject to all the same
licence terms and conditions as Open Sans.